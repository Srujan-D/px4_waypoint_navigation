import rclpy
import math
import random
from threading import Thread

from rclpy.node import Node

from my_services.srv import LidarScan


class Mapping(Node):

    def __init__(self):
        super().__init__('mapping')
        self.cli = self.create_client(LidarScan, 'lidar_scan')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting... ')
        self.req = LidarScan.Request()
        self.response = LidarScan.Response()
        self.req.pos = [200]
        self.req.pos.append(100)
        self.scale = 50  # to scale the grid
        rows, cols = (self.scale, self.scale)
        self.occ_map =  [[0]*cols for i in range(rows)]

    def coordinates(self, theta, dist):
        x = round(self.req.pos[0]+dist*math.cos(theta*math.pi/180))
        y = round(self.req.pos[1]+dist*math.sin(theta*math.pi/180))
        return (x, y)
    
    def line(self, x1, y1, x0, y0):
        lis_x = []
        lis_y = []
        x1c = y1 + 0.5
        y1c = 5 - x1 - 0.5
        y0c = 5 - x0 - 0.5
        x0c = y0 + 0.5
        xa = min(x1c, x0c)
        xb = max(x1c, x0c)
        ya = min(y1c, y0c)
        yb = max(y1c, y0c)
        if (xb != xa):
            m = (yb-ya)/(xb-xa)
        else :
            y = ya
            while y <= yb:
                lis_y += [int(xa - 0.5)]
                lis_x += [int(self.scale - y - 0.5)]
                y = y+1
                return (lis_x, lis_y)
        x = xa
        y = ya
        while x <= xb:
            while y <= yb:
                if abs(y - m*x + m*x0c - y0c) <= 1.0:
                    lis_x += [int(self.scale - y - 0.5)]
                    lis_y += [int(x - 0.5)]
                y += 1
            y = ya
            x += 1
        return (lis_x, lis_y)

    def create_map(self, a= None, b=None):
        if a is None or b is None:          # if next robot state is not passed, set it to random.
            a = random.randint(0, 399)
            b = random.randint(0, 399)
        self.req.pos[0] = a
        self.req.pos[1] = b

        return self.cli.call(self.req)


def main():
    rclpy.init()
    o = Mapping()
    spin_thread = Thread(target=rclpy.spin, args=(o,))
    spin_thread.start()
    next_x = random.randint(0, 399)
    next_y = random.randint(0, 399)
    #o.response = o.create_map()
    for ind in range(10):
        print(ind)
        if (len(o.response.lidar_data) == 0):
            response = o.create_map()
        else:
            response = o.create_map(next_x, next_y)
        while rclpy.ok():

            if (len(response.lidar_data) == 0):     # invalid position
                print('invalid')
                response = o.create_map()
            else:
                for i in range(len(response.lidar_data)):
                    (x, y) = o.coordinates(i, response.lidar_data[i])
                    X = round(x*o.scale/400)
                    Y = round(y*o.scale/400)
                    if x < 0 or y < 0:
                        continue
                    if X >= o.scale:
                        X = o.scale-1
                    if Y >= o.scale:
                        Y = o.scale-1
                    # get a list of indices of the cells lying between line joining two points.
                    (lisX, lisY) = o.line(round(o.req.pos[0]*o.scale/400), round(o.req.pos[1]*o.scale/400), X, Y)
                    if len(lisX) != 0:
                        for k in range(len(lisX)):
                            o.occ_map[round(lisX[k]*o.scale/400)][round(lisY[k]*o.scale/400)] = 1
                (next_x, next_y) = o.coordinates(response.lidar_data.index(max(response.lidar_data))%360, max(response.lidar_data))  # select the farthest point for exploration
                print(o.occ_map)
                if next_x >= 400 :
                    next_x = 399
                if next_y >= 400:
                    next_y = 399
                if next_x < 0:
                    next_x = abs(next_x)%400
                if next_y < 0:
                    next_y = abs(next_y)%400
                
                #response = o.create_map(next_x, next_y)
            break

    o.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
    
