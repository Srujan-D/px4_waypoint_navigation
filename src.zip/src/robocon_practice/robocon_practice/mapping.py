import rclpy
import math
import random
from rclpy.node import Node

from std_msgs.msg import Int64MultiArray, Int64
#from nav_msgs.msg import Odometry


class Mapping(Node):

    def __init__(self):
        super().__init__('mapping')
        self.pub = self.create_publisher(Int64MultiArray, '/position', 10)
        
        # self.sub_odom = self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.sub_lidar = self.create_subscription(Int64MultiArray, '/map', self.lidar_cb, 10)

        #self.sub_odom
        self.sub_lidar

        self.pos = Int64MultiArray()
        self.pos.data = [0,0]
        self.position = self.pos.data
        self.lidar_data = Int64MultiArray()
        self.lidar_data.data = [-1]
        #self.lidar_data = self.lidar_data.data
        rows, cols = (30, 30)
        self.occ_map =  [ [1]*cols for i in range(rows)]

#    def odom_cb(self, msg):
#        self.pos = msg
#        self.pub.publish(self.pos)

    def line(self, x1, y1, x0, y0):
        lis_x = []
        lis_y = []
        
        xa = min(x1, x0)
        xb = max(x1, x0)
        ya = min(y1, y0)
        yb = max(y1, y0)
        if (xb != xa):
            m = (yb-ya)/(xb-xa)
        else :
            for y in range(ya, yb+1):
                lis_y += [y]
                lis_x += [xa]
                return (lis_x, lis_y)
        for x in range(xa, xb+1):
            for y in range(ya, yb+1):
                if abs(y - m*x + m*x0 - y0) <=1:
                    lis_x += [x]
                    lis_y += [y]
        return (lis_x, lis_y)
    
    def lidar_cb(self, msg):
        self.lidar_data = msg
        print("callback")
        #print(self.lidar_data)

    def coordinates(self, theta, dist):
        x = round(self.position[0]+dist*math.cos(theta*math.pi/180))
        y = round(self.position[1]+dist*math.sin(theta*math.pi/180))
        return (x, y)

    def create_map(self):
        self.position[0] = 300
        self.position[1] = 20
        self.pub.publish(self.pos)
        for a in range(10):
            #print(a)
            if (self.lidar_data.data[0] == -1):     # invalid position
                #print('invalid')
                self.position[0] = random.randint(0, 400)
                self.position[1] = random.randint(0, 400)
                #setattr(self.position, random.randint(0, 400), random.randint(0, 400))
            else:
                for i in self.lidar_data.data:

                    (x, y) = self.coordinates(i, self.lidar_data.data(i))
                    X = round(x*30/400)
                    Y = round(y*30/400)
                    if x < 0 or y < 0:
                        continue
                    if X >= 30:
                        X = 29
                    if Y >= 30:
                        Y = 29
                    (lisX, lisY) = self.line(round(self.position[0]*30/400), round(self.position[1]*30/400), X, Y)
                    for k in range(len(lisX)):
                        self.occ_map[lisX[k]][lisY[k]] = 0                #print(self.lidar_data.data)
                (next_x, next_y) = self.coordinates(135, self.lidar_data.data[135])
                self.position[0] = next_x
                self.position[1] = next_y
                #setattr(self.pos, next_x//40, next_y//40)
            #self.pos[0] = randint(0, 400)
            #self.pos[1] = randint(0, 400)
            self.pub.publish(self.pos)
        
        print(self.occ_map)

def main():
    rclpy.init()
    o = Mapping()
    o.create_map()
    
    rclpy.spin(o)
    o.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
    