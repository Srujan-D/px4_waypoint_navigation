import PIL
from PIL import Image
import pathlib
import math
from threading import Thread

import rclpy
from rclpy.node import Node
from my_services.srv import LidarScan


class Lidar(Node):

    def __init__(self):
        super().__init__('lidar')
        self.srv = self.create_service(LidarScan, 'lidar_scan', self.callback)
        
        self.image = Image.open(pathlib.Path('/home/sruj/dev_ws/src/robocon_practice/robocon_practice/map3.jpg'))
        self.image = self.image.convert('1')
        self.image.thumbnail((400, 400))
        self.image_size = min(self.image.size)
        self.no_of_rays = 360

    def callback(self, request, response):
        centerX = request.pos[0]
        centerY = request.pos[1]
        response.lidar_data = []
        if self.image.getpixel((centerX, centerY)) == 0:
            print('invalid')
            
        else:
            for i in range(0,360,int(360/self.no_of_rays)):
                r = 0

                currentX = round(centerX + r*math.cos(i*math.pi/180))
                currentY = round(centerY + r*math.sin(i*math.pi/180))

                while ((currentX < self.image_size and currentX >= 0) and (currentY < self.image_size and currentY >=0) and (self.image.getpixel((currentX, currentY)) != 0)):
                    currentX = round(centerX + r*math.cos(i*math.pi/180))
                    currentY = round(centerY + r*math.sin(i*math.pi/180))
                    r+=1

                response.lidar_data.append(r)

        return response

def main():
    rclpy.init()
    o = Lidar()
    rclpy.spin(o)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
        
