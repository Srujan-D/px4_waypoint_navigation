import PIL
from PIL import Image
import pathlib
import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64MultiArray
import threading
# from nav_msgs.msg import Odometry


class Lidar(Node):

    def __init__(self):
        super().__init__('lidar')
        self.pub = self.create_publisher(Int64MultiArray, '/map', 10)
        
        self.sub = self.create_subscription(Int64MultiArray, '/position', self.callback, 10)
        self.sub
        self.image = Image.open(pathlib.Path('/home/sruj/dev_ws/src/robocon_practice/robocon_practice/map4.jpg'))
        self.image = self.image.convert('1')
        self.image.thumbnail((400, 400))
        self.image_size = min(self.image.size)

        self.return_array = Int64MultiArray()
        self.array = []
        self.no_of_rays = 360

    def callback(self, msg):
        centerX = msg.data[0]
        centerY = msg.data[1]
        if self.image.getpixel((centerX, centerY)) == 0:
            self.return_array.data = [-1]
            print('invalid')
            
        else:
            self.return_array.data = []
            for i in range(0,360,int(360/self.no_of_rays)):
                r = 0

                currentX = round(centerX + r*math.cos(i*math.pi/180))
                currentY = round(centerY + r*math.sin(i*math.pi/180))

                while ((currentX < self.image_size and currentX >= 0) and (currentY < self.image_size and currentY >=0) and (self.image.getpixel((currentX, currentY)) != 0)):
                    currentX = round(centerX + r*math.cos(i*math.pi/180))
                    currentY = round(centerY + r*math.sin(i*math.pi/180))
                    r+=1

                self.return_array.data.append(r)
                #self.return_array.data.append((i,r))
                #self.return_array.append((i, r))
        
        #self.return_array.data = self.array #Int64MultiArray()
        #print(self.return_array.data)
        rclpy.spin(self)
        self.pub.publish(self.return_array)

def main():
    rclpy.init()
    o = Lidar()
    
    o.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
        
