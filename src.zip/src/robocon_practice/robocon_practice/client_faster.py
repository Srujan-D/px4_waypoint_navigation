import rclpy
import math
import random
from threading import Thread

from rclpy.node import Node

from std_msgs.msg import Int64MultiArray
from my_services.srv import LidarScan


class Mapping(Node):

    def __init__(self):
        super().__init__('mapping')
        self.cli = self.create_client(LidarScan, 'lidar_scan')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting... ')
        self.req = LidarScan.Request()
        self.response = LidarScan.Response()
        self.req.pos = [200]
        self.req.pos.append(100)
        self.scale = 50
        rows, cols = (self.scale, self.scale)
        self.occ_map =  [[0]*cols for i in range(rows)]

    def coordinates(self, theta, dist):
        x = round(self.req.pos[0]+dist*math.cos(theta*math.pi/180 ))
        y = round(self.req.pos[1]+dist*math.sin(theta*math.pi/180 ))
        return (x, y)
    
    def line(self, x1, y1, x0, y0):
        lis_x = []
        lis_y = []
        
        xa = min(x1, x0)
        xb = max(x1, x0)
        ya = min(y1, y0)
        yb = max(y1, y0)
        if (xb != xa):
            m = (yb-ya)/(xb-xa)
        else :
            for y in range(ya, yb+1):
                lis_y += [y]
                lis_x += [xa]
                return (lis_x, lis_y)
        for x in range(xa, xb+1):
            for y in range(ya, yb+1):
                if abs(y - m*x + m*x0 - y0) <1:
                    lis_x += [x]
                    lis_y += [y]
        return (lis_x, lis_y)

    def create_map(self):
        self.req.pos[0] = random.randint(0, 399)
        self.req.pos[1] = random.randint(0, 399)

        return self.cli.call(self.req)


def main():
    rclpy.init()
    o = Mapping()
    spin_thread = Thread(target=rclpy.spin, args=(o,))
    spin_thread.start()
    for a in range(20):
        print(a)

        while rclpy.ok():

            response = o.create_map()

            if (len(response.lidar_data) == 0):     # invalid position
                print('invalid')
                o.req.pos[0] = random.randint(0, 399)
                o.req.pos[1] = random.randint(0, 399)
                response.lidar_data = []
                o.create_map()

            else:
                for i in range(len(response.lidar_data)):

                    (x, y) = o.coordinates(i, response.lidar_data[i])
                    X = round(x*o.scale/400)
                    Y = round(y*o.scale/400)
                    if x < 0 or y < 0:
                        continue
                    if X >= o.scale:
                        X = o.scale-1
                    if Y >= o.scale:
                        Y = o.scale-1
                    (lisX, lisY) = o.line(round(o.req.pos[0]*o.scale/400), round(o.req.pos[1]*o.scale/400), X, Y)
                    if len(lisX) != 0:
                        for k in range(len(lisX)):
                            o.occ_map[lisX[k]][lisY[k]] = 1
                (next_x, next_y) = o.coordinates(135, response.lidar_data[135])
                o.req.pos[0] = next_x
                o.req.pos[1] = next_y
                print(o.occ_map)


            break

    o.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
    
